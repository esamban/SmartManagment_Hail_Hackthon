<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Add Income') }}
        </h2>
    </x-slot>
   
<x-jet-authentication-card>
        <x-slot name="logo">
        </x-slot>
       
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
  
    
    <form method="POST" action="{{route('invoices.store')}}" enctype="multipart/form-data" class="dropzone">
        @csrf

        <div class="mt-6">
            <x-jet-label for="item" value="{{ __('item number') }}" />
            <x-jet-input id="item" class="block mt-1 w-full" type="number" name="item" :value="old('CName')" autofocus required />
        </div>

        <div class="mt-6">
            <x-jet-label for="VAT" value="{{ __('VAT') }}" />
            <x-jet-input id="VAT" class="block mt-1 w-full" step="0.00" type="number" name="VAT" :value="old('CName')" autofocus required />
        </div>

        <div class="mt-6">
            <x-jet-label for="PBVAT" value="{{ __('Price Befoer VAT') }}" />
            <x-jet-input id="PBVAT" class="block mt-1 w-full" step="0.00" type="number" name="PBVAT" :value="old('CName')" autofocus required />
        </div>

        <div class="mt-6">
            <x-jet-label for="discount" value="{{ __('Discount') }}" />
            <x-jet-input id="discount" class="block mt-1 w-full" step="0.00" type="number" name="discount" :value="old('CName')" autofocus required />
        </div>
     
        <div class="mt-6">
            <x-jet-label for="total_price" value="{{ __('Total Price') }}" />
            <x-jet-input id="total_price" class="block mt-1 w-full" step="0.00" type="number" name="total_price" :value="old('CName')" autofocus required />
        </div>

        <div class="mt-4">
                <x-jet-label for="sales_field" value="{{ __('Sales Field') }}" />
                <select id="sales_field" class="block mt-1 w-full" type="text" name="sales_field" required  >
                    <option value="Occasions">Occasions</option>
                    <option value="single">single</option>
                </select>
            </div>

        <div class="mt-6">
            <x-jet-label for="date" value="{{ __('Date') }}" />
            <x-jet-input id="date" class="block mt-1 w-full" type="date" name="date" required  />
        </div>

       
            <div class="mt-6">
             <x-jet-button type="submit" class="btn btn-primary">Save</x-jet-button>

            </div>

    </form>
    </x-jet-authentication-card>

</x-app-layout>          
    
